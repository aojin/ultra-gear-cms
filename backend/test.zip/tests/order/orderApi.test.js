const request = require("supertest");
const { PrismaClient } = require("@prisma/client");
const app = require("../../app");

const prisma = new PrismaClient();

describe("Order API Tests", () => {
  let orderId, userId, productId, variantId, cartId;

  beforeAll(async () => {
    try {
      // Create a user
      const user = await prisma.user.create({
        data: {
          name: "Test User",
          email: `testuser-${Date.now()}@example.com`, // Ensure this is unique
          password: "securepassword123", // Add password field
        },
      });
      userId = user.id;

      // Create a product
      const product = await prisma.product.create({
        data: {
          name: "Test Product",
          description: "Test Description",
          msrpPrice: 100.0,
          currentPrice: 90.0,
          brand: "Test Brand",
          model: "Test Model",
        },
      });
      productId = product.id;

      // Create a product variant
      const variant = await prisma.productVariant.create({
        data: {
          size: "L",
          color: "Red",
          stock: 10,
          productId: productId,
        },
      });
      variantId = variant.id;

      // Create a cart
      const cart = await prisma.cart.create({
        data: {
          userId: userId,
        },
      });
      cartId = cart.id;

      // Add item to cart
      await prisma.cartItem.create({
        data: {
          cartId: cartId,
          variantId: variantId,
          quantity: 2,
        },
      });
    } catch (error) {
      console.error("Error setting up test data:", error);
    }
  });

  afterAll(async () => {
    try {
      // Clean up created entities
      if (orderId) await prisma.order.delete({ where: { id: orderId } });
      if (cartId) await prisma.cart.delete({ where: { id: cartId } });
      if (userId) await prisma.user.delete({ where: { id: userId } });
      if (productId) await prisma.product.delete({ where: { id: productId } });
      if (variantId)
        await prisma.productVariant.delete({ where: { id: variantId } });
    } catch (error) {
      console.error("Error cleaning up test data:", error);
    } finally {
      await prisma.$disconnect();
    }
  });

  it("should create a new Order", async () => {
    const res = await request(app).post("/api/orders").send({
      userId: userId,
      cartId: cartId,
      shippingAddress: "123 Test St, Test City, TX 12345",
      totalAmount: 180.0,
    });

    console.error("Error creating order:", res.body); // Log error details

    expect(res.statusCode).toEqual(201); // Adjusted to 201 Created
    expect(res.body).toHaveProperty("id");
    orderId = res.body.id; // Save orderId for further tests
  });

  it("should update an Order", async () => {
    const res = await request(app).put(`/api/orders/${orderId}`).send({
      shippingAddress: "456 Updated St, Updated City, TX 67890",
    });

    console.error("Error updating order:", res.body); // Log error details

    expect(res.statusCode).toEqual(200); // Adjusted to 200 OK
    expect(res.body).toHaveProperty(
      "shippingAddress",
      "456 Updated St, Updated City, TX 67890"
    );
  });

  it("should retrieve an Order by ID", async () => {
    const res = await request(app).get(`/api/orders/${orderId}`);

    expect(res.statusCode).toEqual(200);
    expect(res.body).toHaveProperty("id", orderId);
    expect(res.body).toHaveProperty(
      "shippingAddress",
      "456 Updated St, Updated City, TX 67890"
    );
  });

  it("should delete an Order", async () => {
    const res = await request(app).delete(`/api/orders/${orderId}`);

    expect(res.statusCode).toEqual(204);

    // Verify deletion
    const deletedRes = await request(app).get(`/api/orders/${orderId}`);
    expect(deletedRes.statusCode).toEqual(404);
  });
});
