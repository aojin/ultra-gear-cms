import express from "express";
import {
  createProductHandler,
  getAllProductsHandler,
  getProductByIdHandler,
  updateProductHandler,
  deleteProductPermanentlyHandler,
  archiveProductHandler,
  unarchiveProductHandler,
} from "../controllers/productController.js";

const router = express.Router();

router.post("/products", createProductHandler);
router.get("/products", getAllProductsHandler);
router.get("/products/:id", getProductByIdHandler);
router.put("/products/:id", updateProductHandler);
router.delete("/products/:id", deleteProductPermanentlyHandler);
router.post("/products/:id/archive", archiveProductHandler);
router.post("/products/:id/unarchive", unarchiveProductHandler);

export default router;
