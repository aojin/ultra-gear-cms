import express from "express";
import {
  getAllProductVariants,
  getProductVariantById,
  createProductVariant,
  updateProductVariant,
  deleteProductVariant,
  unarchiveProductVariant,
  archiveProductVariant,
} from "../controllers/productVariantController.js";

const router = express.Router();

router.post("/", createProductVariant);
router.get("/", getAllProductVariants);
router.get("/:id", getProductVariantById);
router.put("/:id", updateProductVariant);
router.put("/:id/archive", archiveProductVariant);
router.put("/:id/unarchive", unarchiveProductVariant);
router.delete("/:id", deleteProductVariant);

export default router;
